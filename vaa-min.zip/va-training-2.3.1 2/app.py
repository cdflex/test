from flask import Flask, request, jsonify
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    files = []
    for key in request.files:
        file = request.files[key]
        if file:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_path)
            files.append(file.filename)

    if files:
        return jsonify({'message': f'Uploaded files: {", ".join(files)}'})
    return jsonify({'message': 'No files uploaded'})

if __name__ == '__main__':
    app.run(debug=True)