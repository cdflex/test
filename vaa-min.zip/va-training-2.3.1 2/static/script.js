const chatWindow = document.getElementById('chatWindow');
const chatInput = document.getElementById('chatInput');
const uploadButton = document.getElementById('upload-button');
const fileInputs = [
    document.getElementById('qa-xls-upload'),
    document.getElementById('info-doc-upload'),
    document.getElementById('menu-pdf-upload')
];

function sendMessage() {
    const message = chatInput.value.trim();
    if (message) {
        const userMessage = document.createElement('div');
        userMessage.className = 'chat-message user';
        userMessage.innerHTML = `<p>${message}</p>`;
        chatWindow.appendChild(userMessage);

        const systemMessage = document.createElement('div');
        systemMessage.className = 'chat-message system';
        systemMessage.innerHTML = `<p>Got it! Let me check...</p>`;
        chatWindow.appendChild(systemMessage);

        chatInput.value = '';
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }
}

chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

uploadButton.addEventListener('click', () => {
    const formData = new FormData();
    fileInputs.forEach((input, index) => {
        if (input.files.length > 0) {
            formData.append(`file${index}`, input.files[0]);
        }
    });

    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error('Error uploading files:', error);
        alert('Error uploading files');
    });
});