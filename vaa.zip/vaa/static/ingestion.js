async function fetchUploadedFiles() {
    try {
        const response = await fetch('/list_files');
        const data = await response.json();
        
        if (response.ok) {
            const tableBody = document.getElementById('file-table-body');
            tableBody.innerHTML = '';
            data.forEach(file => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td><input type="checkbox" class="file-checkbox" data-filename="${file}"></td>
                    <td>${file}</td>
                    <td class="status" data-filename="${file}">Uploaded</td>
                `;
                tableBody.appendChild(row);
            });
            updateIngestButton();
        } else {
            console.error('Failed to fetch uploaded files:', data.error);
            alert('Error fetching uploaded files: ' + data.error);
        }
    } catch (error) {
        console.error('Error fetching uploaded files:', error);
        alert('Error fetching uploaded files: ' + error.message);
    }
}

async function uploadFiles() {
    const fileInput = document.getElementById('file-input');
    const files = fileInput.files;
    if (files.length === 0) {
        alert("Please select at least one file to upload.");
        return;
    }

    // Show the uploading popup
    const modal = document.getElementById('upload-modal');
    modal.style.display = 'flex';
    modal.classList.add('show');

    const formData = new FormData();
    for (let file of files) {
        formData.append('files', file);
    }

    try {
        const response = await fetch('/upload_files', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        // Hide the popup
        modal.classList.remove('show');
        modal.style.display = 'none';

        if (response.ok) {
            // Refresh the file list
            await fetchUploadedFiles();
        } else {
            alert('Upload failed: ' + result.error);
        }
    } catch (error) {
        console.error('Upload failed:', error);
        modal.classList.remove('show');
        modal.style.display = 'none';
        alert('Upload failed: ' + error.message);
    }
}

function updateIngestButton() {
    const checkboxes = document.querySelectorAll('.file-checkbox:checked');
    const ingestBtn = document.getElementById('ingest-btn');
    ingestBtn.disabled = checkboxes.length === 0;
}

async function ingestFiles() {
    const checkboxes = document.querySelectorAll('.file-checkbox:checked');
    const files = Array.from(checkboxes).map(cb => cb.dataset.filename);
    const statusDisplay = document.getElementById('ingestion-status');

    if (files.length === 0) return;

    statusDisplay.textContent = 'Selected: ' + files.join(', ');
    statusDisplay.className = 'status selected';

    // Update status to Parsing
    files.forEach(file => {
        const statusCell = document.querySelector(`.status[data-filename="${file}"]`);
        statusCell.textContent = 'Parsing';
        statusCell.className = 'status parsing';
    });

    // Send ingestion request
    const response = await fetch('/ingest_files', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files })
    });
    const result = await response.json();

    // Update status to Ingesting
    files.forEach(file => {
        const statusCell = document.querySelector(`.status[data-filename="${file}"]`);
        statusCell.textContent = 'Ingesting';
        statusCell.className = 'status ingesting';
    });

    // Simulate ingestion process
    setTimeout(() => {
        files.forEach(file => {
            const statusCell = document.querySelector(`.status[data-filename="${file}"]`);
            statusCell.textContent = 'Done';
            statusCell.className = 'status done';
        });
        statusDisplay.textContent = 'Ingestion Complete: ' + files.join(', ');
        statusDisplay.className = 'status done';
    }, 2000);
}

// Initialize file list
fetchUploadedFiles();

// Update ingest button on checkbox change
document.addEventListener('change', (e) => {
    if (e.target.classList.contains('file-checkbox')) {
        updateIngestButton();
    }
});