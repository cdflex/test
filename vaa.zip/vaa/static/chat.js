async function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');
    const errorDisplay = document.getElementById('chat-error');
    const query = userInput.value.trim();

    if (!query) return;

    // Display user message
    const userMessage = document.createElement('div');
    userMessage.className = 'message user';
    userMessage.textContent = query;
    chatBox.appendChild(userMessage);
    userInput.value = '';

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;

    try {
        const response = await fetch('/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query })
        });
        const data = await response.json();

        if (response.ok) {
            // Display bot response
            const botMessage = document.createElement('div');
            botMessage.className = 'message bot';
            botMessage.textContent = data.answer;
            chatBox.appendChild(botMessage);
            errorDisplay.textContent = '';

            // Speak the bot's response
            speakResponse(data.answer);
        } else {
            errorDisplay.textContent = data.error || 'Failed to get response from the server.';
        }
    } catch (error) {
        console.error('Query failed:', error);
        errorDisplay.textContent = 'Error: ' + error.message;
    }

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;
}

function speakResponse(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';
        utterance.rate = 1.0; // Speed of speech
        utterance.pitch = 1.0; // Pitch of speech
        window.speechSynthesis.speak(utterance);
    } else {
        console.error('Text-to-speech not supported in this browser.');
        document.getElementById('chat-error').textContent = 'Text-to-speech not supported in this browser.';
    }
}

let recognition;
let isListening = false;

function toggleVoice() {
    const voiceBtn = document.getElementById('voice-btn');
    const errorDisplay = document.getElementById('chat-error');

    if (!('webkitSpeechRecognition' in window)) {
        errorDisplay.textContent = 'Speech recognition not supported in this browser. Please use Chrome.';
        return;
    }

    if (!isListening) {
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true; // Enable interim results for real-time transcription
        recognition.lang = 'en-US';

        recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';

            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }

            // Update the input field with interim and final transcripts
            document.getElementById('user-input').value = finalTranscript + interimTranscript;

            // If the result is final, send the message
            if (finalTranscript) {
                sendMessage();
            }
        };

        recognition.onerror = (event) => {
            errorDisplay.textContent = 'Speech recognition error: ' + event.error;
            voiceBtn.textContent = 'Start Voice';
            isListening = false;
        };

        recognition.onend = () => {
            voiceBtn.textContent = 'Start Voice';
            isListening = false;
        };

        recognition.start();
        voiceBtn.textContent = 'Stop Voice';
        isListening = true;
    } else {
        recognition.stop();
        voiceBtn.textContent = 'Start Voice';
        isListening = false;
    }
}