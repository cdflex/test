brew install python@3.10

/usr/local/bin/python3.10 -m venv venv
source venv/bin/activate
pip install flask python-docx pandas faiss-cpu huggingface_hub requests

pip install faiss-cpu==1.7.4

pip install openpyxl 
pip install transformers torch


pip install "numpy<2"






Identify Dependencies
The app.py file and the overall project use the following libraries and packages:

Flask: The web framework used to build the application.
Used for routing (app.route), handling requests (request), and serving templates (send_from_directory).
docx (python-docx): For reading .docx files in the extract_text_from_docx function.
pandas: For reading Excel files (extract_text_from_excel).
faiss-cpu: For similarity search using the FAISS index (IndexFlatL2).
numpy: For numerical operations, especially with embeddings (np.vstack, np.array).
json: For reading and writing JSON files (e.g., knowledge_base.json, prompt.json, metrics.json). This is part of Python's standard library, so it doesn't need to be listed in requirements.txt.
huggingface_hub: For interacting with the Hugging Face Inference API (InferenceClient).
requests: For making HTTP requests to the OCR Space API (requests.post).
base64: For encoding PDF files to base64 format. This is part of Python's standard library.
logging: For logging debug information. This is part of Python's standard library.
transformers: For loading the local embedding model (AutoTokenizer, AutoModel).
torch: Required by the transformers library for model inference (torch.no_grad, torch.cuda.empty_cache).
PyMuPDF (fitz): For local PDF text extraction (extract_text_from_pdf_local).
uuid: For generating unique document IDs (uuid4). This is part of Python's standard library.


pip install -r requirements.txt
