async function sendMessage() {
    const userInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-messages');
    const errorDisplay = document.getElementById('chat-error');
    const query = userInput.value.trim();

    if (!query) return;

    // Display user message
    const userMessage = document.createElement('div');
    userMessage.className = 'message user';
    userMessage.textContent = query;
    chatBox.appendChild(userMessage);
    userInput.value = '';

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;

    try {
        const response = await fetch('/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query })
        });
        const data = await response.json();

        if (response.ok) {
            // Display bot response
            const botMessage = document.createElement('div');
            botMessage.className = 'message bot';
            botMessage.textContent = data.answer;
            chatBox.appendChild(botMessage);
            errorDisplay.textContent = '';

            // Speak the bot response
            const utterance = new SpeechSynthesisUtterance(data.answer);
            utterance.lang = 'en-US';
            utterance.volume = 1.0;
            utterance.pitch = 1.0;
            utterance.rate = 1.0;
            window.speechSynthesis.speak(utterance);
        } else {
            errorDisplay.textContent = data.error || 'Failed to get response from the server.';
        }
    } catch (error) {
        console.error('Query failed:', error);
        errorDisplay.textContent = 'Error: ' + error.message;
    }

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;
}

let recognition;
let isListening = false;

function toggleVoice() {
    const voiceBtn = document.getElementById('voice-btn');
    const errorDisplay = document.getElementById('chat-error');

    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
        errorDisplay.textContent = 'Speech recognition not supported in this browser. Please use Chrome or Edge.';
        return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!isListening) {
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';

            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }

            // Update the input field with interim and final transcripts
            document.getElementById('chat-input').value = finalTranscript + interimTranscript;
        };

        recognition.onerror = (event) => {
            errorDisplay.textContent = 'Speech recognition error: ' + event.error;
            voiceBtn.textContent = 'Start Voice';
            isListening = false;
        };

        recognition.onend = () => {
            voiceBtn.textContent = 'Start Voice';
            isListening = false;
            // Automatically send the transcribed query
            if (document.getElementById('chat-input').value.trim()) {
                sendMessage();
            }
        };

        recognition.start();
        voiceBtn.textContent = 'Stop Voice';
        isListening = true;
    } else {
        recognition.stop();
        voiceBtn.textContent = 'Start Voice';
        isListening = false;
        // Trigger query on stop
        if (document.getElementById('chat-input').value.trim()) {
            sendMessage();
        }
    }
}

// Handle Enter key
document.addEventListener('DOMContentLoaded', () => {
    const userInput = document.getElementById('chat-input');
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});