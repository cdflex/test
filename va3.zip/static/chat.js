async function sendMessage() {
    const userInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-messages');
    const errorDisplay = document.getElementById('chat-error');
    const query = userInput.value.trim();

    if (!query) return;

    // Display user message
    const userMessage = document.createElement('div');
    userMessage.className = 'message user';
    userMessage.textContent = query;
    chatBox.appendChild(userMessage);
    userInput.value = '';

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;

    try {
        const response = await fetch('/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query })
        });
        const data = await response.json();

        if (response.ok) {
            // Display bot response
            const botMessage = document.createElement('div');
            botMessage.className = 'message bot';
            botMessage.textContent = data.answer;
            chatBox.appendChild(botMessage);
            errorDisplay.textContent = '';
        } else {
            errorDisplay.textContent = data.error || 'Failed to get response from the server.';
        }
    } catch (error) {
        console.error('Query failed:', error);
        errorDisplay.textContent = 'Error: ' + error.message;
    }

    // Scroll to the bottom
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Handle Enter key
document.addEventListener('DOMContentLoaded', () => {
    const userInput = document.getElementById('chat-input');
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});